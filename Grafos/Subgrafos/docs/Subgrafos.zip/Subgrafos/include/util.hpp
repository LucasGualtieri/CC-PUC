#ifndef UTIL_HPP
#define UTIL_HPP

#define extends public
#define implements public

template <typename T>
void swap(T& a, T& b) {
	T aux = a;
	a = b;
	b = aux;
}

#endif