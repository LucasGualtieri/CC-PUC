import java.util.Scanner;

public class teste {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		System.out.println("Olá mundo!");

		scanner.close();

		System.out.println("\n ----- | FIM DO PROGRAMA | ----- \n");
	}
}