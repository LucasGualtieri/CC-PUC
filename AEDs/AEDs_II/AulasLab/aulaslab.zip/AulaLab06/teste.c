#include "..\Bibliotecas\biblioteca_c.h"

int main() {

	printf("Olá mundo!\n");

	printf("\n******* | FIM DO PROGRAMA | *******\n\n");
	return 0;
}